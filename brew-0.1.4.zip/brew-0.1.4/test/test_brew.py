"""
Tests for `brew` module.
"""
import pytest


class TestBrew(object):

    @classmethod
    def setup_class(cls):
        pass

    def test_something(self):
        pass

    @classmethod
    def teardown_class(cls):
        pass
