from brew.selection.pruning.epic import EPIC

__all__ = ['EPIC']
