.. :changelog:

History
-------

0.1.0 (2014-11-12)
++++++++++++++++++

* First release on PyPI.
