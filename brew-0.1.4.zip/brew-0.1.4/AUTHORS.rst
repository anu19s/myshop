=======
Credits
=======

This project was started in 2014 by *Dayvid Victor* and *Thyago Porpino*
as a project for the Multiple Classifier Systems class at Federal University of Pernambuco (UFPE).

Nowdays, this project is part of Dayvid's PhD thesis on Ensemble Learning.

Development Lead
----------------

* Dayvid Victor <victor.dvro@gmail.com>
* Thyago Porpino <thyago.porpino@gmail.com>

Contributors
------------

None yet. Why not be the first?
